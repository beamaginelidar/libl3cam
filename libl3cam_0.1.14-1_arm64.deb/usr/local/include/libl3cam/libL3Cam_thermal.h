//==============================================================================
//
// Title:		libL3Cam_thermal
// Purpose:		Interface of the library for communications with L3CAM devices thermal sensor
//
// Created on:	05/07/2023 at 12:00:00 by Beamagine.
// Copyright:	. All Rights Reserved.
//
//==============================================================================

#ifndef __libL3Cam_thermal_H__
#define __libL3Cam_thermal_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files
#ifdef _WIN32
#include "cvidef.h"
#endif
#include "beamagine.h"
#include "beamErrors.h"

//! @brief  Changes the colormap of the thermal image
//! @param  device The device to execute the function
//! @param  colormap The desired colormap
//! @return 0 if OK otherwise Error, check error definition
int CHANGE_THERMAL_CAMERA_COLORMAP(l3cam device, thermalTypes colormap);

//! @brief  Enables/disables the temperature filter of the thermal image
//! @param  device The device to execute the function
//! @param  enabled Boolean to enable or disable the filter
//! @return 0 if OK otherwise Error, check error definition
int ENABLE_THERMAL_CAMERA_TEMPERATURE_FILTER(l3cam device, bool enabled);

//! @brief  Changes the thermal temperature filter values
//! @param  device The device to execute the function
//! @param  min_temperature Min value in ºC to show -40ºC to 200ºC
//! @param  max_temperature Max value in ºC to show -40ºC to 200ºC
//! @return 0 if OK otherwise Error, check error definition
int CHANGE_THERMAL_CAMERA_TEMPERATURE_FILTER(l3cam device, float min_temperature, float max_temperature);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __libL3Cam_thermal_H__ */
